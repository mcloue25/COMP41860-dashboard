// src/lib/fakeRag.ts
export function fakeRagAnswer(_question: string) {
  return "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
}
